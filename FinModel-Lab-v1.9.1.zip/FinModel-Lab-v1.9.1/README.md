# FinModel Lab v1.9.1 · 交互稳定性与课程目录统一

现有五模型：06 GARCH递推、07 VaR/ES、08 均值-方差、09 CAPM、11 Black-Scholes。保留原三栏、字体、R语句解析、教学探索和课堂资料。全站目录严格按12个课程实验排序；01–05、10、12暂未上线。

本轮完成共享Hover/Click状态、五模型图表交互、统一12项目录、模态焦点和投屏目录入口。完整根因、文件清单、实际测试和已知限制见 [CHANGES-v1.9.1.md](CHANGES-v1.9.1.md)，截图见 [实际验收画廊](tests/v1.9.1/gallery.html)，规范见 [DESIGN-SYSTEM.md](DESIGN-SYSTEM.md)。

实际验证：355项新增Chrome交互检查、22项补充交互检查、254项既有教学/布局检查、9套数学/教学回归全部通过；另有50组教学R执行、312次数值比对。Safari07/11及原生125%作7项抽查。Safari鼠标压力矩阵、Chrome原生125%完整页面尚未验收，不宣称全浏览器覆盖。

最新交付包：`FinModel-Lab-v1.9.1.zip`。旧版本包保留。

## 本地启动

在本项目目录运行，无需安装前端依赖：

```sh
python3 tools/serve.py
```

打开 http://127.0.0.1:8765/?v=1.9.1 。字体和KaTeX均自托管。首次替换旧版本后可强制刷新，避免缓存旧HTML。

原启动命令仍可用（同一端口只启动一个服务）：

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

正式课堂部署参见DEPLOYMENT.md；127.0.0.1仅为本机预览。

## 实验08原有操作

- 右侧调参，代码、曲线、收益、方差和风险同步。“设为比较基准”后再编辑；“查看变化”展示完整快照；“结束比较”清空差异与图表比较基准。
- 点击“有效/非有效组合”查看数学证据。非有效时展示可行支配配置，主动应用后可撤销；不自动修改输入。
- 高收益等合法极端假设只提示，不改写；同一分析期口径。非法输入保留上次有效结果。
- 下拉选择相关系数或有效前沿探索。先预测再确认，前者只开放ρ，后者只开放权重，再查看解释。退出可恢复或保留参数。
- 点R行查看作用、公式、代入和金融含义。代码/解释局部滚动，分隔条可拖动/按键调整；复制的基础R可整体运行。
- “课堂工具”包含A/B/C示例、4道理解题和教师同意后主动本地导出的匿名反馈。加载示例明确重置参数/比较/探索。无自动上传、无行为跟踪、无登录。
- 刷新回默认且清空实验状态；不同标签页独立。

## v1.8保留资料

- CHANGES-v1.8.md：修改清单、完成/部分/未完成、数学报告与实际测试。
- CLASSROOM-GUIDE.md：教师演示与学生练习。
- EVALUATION-PLAN.md：平行前后测、答案、评分、真实反馈口径。
- DEPLOYMENT.md：部署方式及待补测项目。
- tests/v1.8/gallery.html：截图；checks.json：实际浏览器断言；unit-results.json：命令结果。
- FONTS.md：字体与许可。dist/是完整可部署静态文件。
- FinModel-Lab-v1.8.zip：原历史包保留；历史交付包为FinModel-Lab-v1.9.zip。

## 复核测试

新旧套件统一复核：`node tests/run-regression.cjs`。修改工作台/新实验源模块后需执行`node tools/build-workbench.cjs`，已交付静态文件无需构建。

```sh
node tests/math.test.cjs
node tests/learning.test.cjs
node tests/numerics.test.cjs
node tests/scale.test.cjs
node tests/r-code.test.cjs
node tests/typography.test.cjs
node tests/exploration.test.cjs
node tests/teaching.test.cjs
```

本轮9套回归全部实际通过。交互浏览器验收使用 `tests/interaction191.test.cjs`，既有教学/布局使用 `tests/ui-refinement.test.cjs`（需要Playwright和已安装Chrome）；`tests/presentation.test.cjs` 以Rscript执行基础/完整教学代码。测试结果按版本存档，历史报告中的数字不视为本轮新检查。

当前未取得本地直接HTTP并发通过结果（连接重置），未做弱网/目标部署容量/真实跨设备课堂验证。尚无真实教师或学生试用及效果数据。本版是课堂试用候选，不宣称正式全班可用；未远程发布。
