// Ordered static bundles. Source modules stay readable and independently testable.
const fs=require('node:fs'),path=require('node:path');const root=path.join(__dirname,'..','dist');const bundles={
 'portfolio-bundle.js':['chart-interaction.js','experiments-config.js','modal-ui.js','math.js','chart-scale.js','teaching.js','lessons.js','vendor/katex/katex.min.js','typography.js','exploration.js','classroom-ui.js','app.js'],
 'experiments-bundle.js':['chart-interaction.js','experiments-config.js','modal-ui.js','vendor/katex/katex.min.js','experiment-math.js','experiment-lessons.js','workbench-ui.js','lesson-presentation.js','financial-charts.js','experiments.js']
};for(const[name,files]of Object.entries(bundles)){const bundle=files.map(file=>`\n/* Source: ${file} */\n${fs.readFileSync(path.join(root,file),'utf8')}\n;`).join('\n');fs.writeFileSync(path.join(root,name),bundle);}
