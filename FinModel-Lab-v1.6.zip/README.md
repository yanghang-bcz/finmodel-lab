# FinModel Lab v1.6

教学体验精修与代码简化。沿用现有静态项目、三栏、字体与实验08金融核心。

## 启动

在项目目录运行：

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

打开 http://127.0.0.1:8765/ 。无需安装前端依赖或R包；网页不依赖联网字体、行情和R服务。

## 使用

点击代码语句查看同一公式、参数代入与结果。默认38行基础R可直接复制到RStudio运行，不含机器精度、容差或断言；完全负相关或风险接近抵消时会补充有中文解释的等价方差步骤。

拖动代码与解析之间的分隔条，代码可占40%～80%；方向键每次调整5个百分点，Home/End设置边界。“展开解析”保留40%代码并扩大解析，收起恢复原比例。两区各自滚动。

图表默认自动适配当前曲线，权重变化不会改变坐标；右上角可切换固定比较并查看基准虚线，超范围时明确扩展。

“开始探索”依次完成预测→实验→解释。预测后只允许调整rho，采用共同坐标。可重新开始或退出；rho=-1时先提供有效起点。零权重或零波动率时风险不变。

当前组合与最小方差点支持点击、键盘与图例查看；浮层可切换重合点身份。投屏保留代码、公式、参数、曲线和进行中的探索；Escape退出。其他实验仍显示暂未上线。

## 验收与交付

- 完整文件清单、状态、计算和测试：CHANGES-v1.6.md。
- 实际截图：tests/v1.6/gallery.html。
- 65项浏览器检查：tests/v1.6/checks.json。
- 字体与授权：FONTS.md及dist/assets/。
- 当前项目包：FinModel-Lab-v1.6.zip。

```sh
node tests/math.test.cjs
node tests/learning.test.cjs
node tests/numerics.test.cjs
node tests/scale.test.cjs
node tests/r-code.test.cjs
node tests/typography.test.cjs
```

实际通过：54,159个可行点核对、384组数值一致性、16组真实R执行、120个公式/计算；另对浏览器复制出的默认/负相关脚本实际运行Rscript。tests/browser.test.cjs为可选Playwright重放，本轮浏览器验收使用实际连接的内置浏览器。未执行远程发布或真实课堂试用。
