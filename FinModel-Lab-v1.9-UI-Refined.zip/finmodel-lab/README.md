# FinModel Lab v1.9 · UI精修版（课堂试用候选）

在v1.8原项目上增加实验07 VaR/ES、实验11 Black–Scholes、实验06 GARCH(1,1)递推与实验09 CAPM。保留实验08、原字体与三栏工作台。各模块含中文代码解析、实时图表、可运行基础R、预测探索与教师提示；实验01/04仍暂未上线。

本轮UI修复、实际文件清单及限制见 [CHANGES-v1.9-UI.md](CHANGES-v1.9-UI.md)，统一规范见 [DESIGN-SYSTEM.md](DESIGN-SYSTEM.md)，最新截图见 [UI验收画廊](tests/ui-refinement/gallery.html)。历史模型开发报告仍保留在 [CHANGES-v1.9.md](CHANGES-v1.9.md)。

本轮真实验证：254项Chrome完整UI检查、18项额外压力检查、50组基础/完整代码R运行、9份实际复制R执行，原9套回归通过。Safari已作实际窗口与原生125%抽查；覆盖范围小于Chrome，详见报告。未将版本标记为所有浏览器/缩放场景完全验收。

最新交付包：FinModel-Lab-v1.9-UI-Refined.zip。旧v1.8/v1.9历史包保留。

## 启动（原命令）

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

在项目目录运行，打开 http://127.0.0.1:8765/ 。无需安装前端依赖；字体和KaTeX自托管。正式课堂不能把127.0.0.1当作学生访问地址，见DEPLOYMENT.md。

## 实验08原有操作

- 右侧调参，代码、曲线、收益、方差和风险同步。“设为比较基准”后再编辑；“查看变化”展示完整快照；“结束比较”清空差异与图表比较基准。
- 点击“有效/非有效组合”查看数学证据。非有效时展示可行支配配置，主动应用后可撤销；不自动修改输入。
- 高收益等合法极端假设只提示，不改写；同一分析期口径。非法输入保留上次有效结果。
- 下拉选择相关系数或有效前沿探索。先预测再确认，前者只开放ρ，后者只开放权重，再查看解释。退出可恢复或保留参数。
- 点R行查看作用、公式、代入和金融含义。代码/解释局部滚动，分隔条可拖动/按键调整；复制的基础R可整体运行。
- “课堂工具”包含A/B/C示例、4道理解题和教师同意后主动本地导出的匿名反馈。加载示例明确重置参数/比较/探索。无自动上传、无行为跟踪、无登录。
- 刷新回默认且清空实验状态；不同标签页独立。

## v1.8保留资料

- CHANGES-v1.8.md：修改清单、完成/部分/未完成、数学报告与实际测试。
- CLASSROOM-GUIDE.md：教师演示与学生练习。
- EVALUATION-PLAN.md：平行前后测、答案、评分、真实反馈口径。
- DEPLOYMENT.md：部署方式及待补测项目。
- tests/v1.8/gallery.html：截图；checks.json：实际浏览器断言；unit-results.json：命令结果。
- FONTS.md：字体与许可。dist/是完整可部署静态文件。
- FinModel-Lab-v1.8.zip：原历史包保留；本轮交付包为FinModel-Lab-v1.9.zip。

## 复核测试

新旧套件统一复核：`node tests/run-regression.cjs`。修改工作台/新实验源模块后需执行`node tools/build-workbench.cjs`，已交付静态文件无需构建。

```sh
node tests/math.test.cjs
node tests/learning.test.cjs
node tests/numerics.test.cjs
node tests/scale.test.cjs
node tests/r-code.test.cjs
node tests/typography.test.cjs
node tests/exploration.test.cjs
node tests/teaching.test.cjs
```

以上本轮均真实通过。实际复制的C/改进配置R也已执行。独立tests/browser.test.cjs未运行；浏览器验收使用已连接内置浏览器。

当前未取得本地直接HTTP并发通过结果（连接重置），未做弱网/目标部署容量/真实跨设备课堂验证。尚无真实教师或学生试用及效果数据。本版是课堂试用候选，不宣称正式全班可用；未远程发布。
