# FinModel Lab 字体与图表比例核对

图表已由偏高的 560×600 画布、非等比填充，改为 560×420（4:3）画布并等比例缩放。桌面实测453.20×339.90，圆点约9.71×9.71；手机及投屏同样等比。仅调整显示坐标，不改变金融计算。

## 字体说明

下表是1440×900普通模式下，从浏览器读取的字体配置、字号和字重。`font-family` 返回的是字体回退列表，不能将其误认为每个字符实际命中的字体文件。

- 系统无衬线：`-apple-system, BlinkMacSystemFont, Segoe UI, PingFang SC, sans-serif`。macOS 英文通常为 San Francisco（SF Pro），中文通常为苹方；Windows通常为Segoe UI，中文可能由本机中文字体回退。页面没有下载或嵌入外部字体。
- 系统等宽：`ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`。macOS通常为SF Mono，后备Menlo；Windows通常回退Consolas。
- 品牌名称：首选Avenir Next，中文后备PingFang SC。
- Logo字母：Georgia斜体。
- 图表：`-apple-system, PingFang SC, sans-serif`。其14/15是SVG内部字号，1440视口下等比缩放后约11.3/12.1屏幕像素。

## 各区域配置

| 区域 | 字体回退列表 | 字号 | 字重 |
|---|---|---|---|
| Logo字母 | Georgia | 39px | 400 |
| 品牌名称 | "Avenir Next", "PingFang SC", sans-serif | 16px | 600 |
| 品牌Lab | "Avenir Next", "PingFang SC", sans-serif | 11px | 400 |
| 顶部实验标题 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 18px | 550 |
| 顶部品牌 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 15px | 500 |
| 侧栏导航 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 13px | 400 |
| 面板标题 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 16px | 550 |
| R代码 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 14px | 400 |
| 行号 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 10px | 400 |
| 解释标题 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 14px | 600 |
| 解释正文 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 13px | 400 |
| 数学公式 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 12px | 400 |
| 数值代入 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 12px | 400 |
| 结果 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 13px | 600 |
| 指标标签 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 11px | 400 |
| 指标数值 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 29px | 500 |
| 图表刻度 | -apple-system, "PingFang SC", sans-serif | 14px | 400 |
| 图表轴名 | -apple-system, "PingFang SC", sans-serif | 15px | 400 |
| 图内标签 | -apple-system, "PingFang SC", sans-serif | 14px | 400 |
| 图例 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 11px | 400 |
| 参数组标题 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 13px | 550 |
| 资产标签 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 12px | 400 |
| 权重数值 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 20px | 500 |
| 参数表 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 11px | 400 |
| 参数输入 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 13px | 400 |
| 滑块刻度 | ui-monospace, SFMono-Regular, Menlo, Consolas, monospace | 10px | 400 |
| 面板按钮 | -apple-system, "system-ui", "Segoe UI", "PingFang SC", sans-serif | 11px | 400 |

## 其他区域与模式

- 方差三项贡献的标签：系统无衬线11px；数值：系统等宽12px。经济含义与展开说明11px。
- 点详情/探索题：正文系统无衬线12px；点详情数值系统等宽13px，辅助标签11px。
- 帮助正文系统无衬线13px，段落标题14px；弹窗标题18px；目录条目13px、状态文字11px。
- 投屏：代码17px，说明正文14px、说明标题15px、公式与代入13px、主指标32px。
- 手机：主标题14px，组标题14px，数值输入14px，主指标28px，权重22px；代码14px，手机投屏代码15px。
- 1024～1250px：面板标题15px、主指标25px、输入12px、参数表10px。

修改文件：`dist/index.html`、`dist/style.css`、`dist/app.js`。修改后的截图：`tests/v1.2/chart-ratio-fixed.jpg`、`chart-normal-ratio.jpg`；字体原始记录：`fonts.json`。
