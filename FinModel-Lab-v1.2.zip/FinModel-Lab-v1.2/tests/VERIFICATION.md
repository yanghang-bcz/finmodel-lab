# FinModel Lab 验收入口

当前版本：v1.2，2026-10-16（Asia/Shanghai）。

完整修改矩阵与结果见 `../CHANGES-v1.2.md`。

当前版本的真实浏览器截图、尺寸记录、42项检查结果及实际剪贴板 R 脚本均在 `v1.2/`。

旧版 `mobile.jpg`、`projector.jpg`、`layout-desktop.json` 是 v1.1 留档，不作为 v1.2 验收证据。

自动化计算和教学测试：

```sh
node tests/math.test.cjs
node tests/learning.test.cjs
node tests/r-code.test.cjs
```

通过：54,159个可行点，参数与教学边界，13组真实R执行；实际剪贴板脚本另行运行通过。

浏览器交互通过已连接的 Codex 内置浏览器实际完成，详见 `v1.2/browser-results.json`。本次没有在终端独立执行 `browser.test.cjs`；该脚本已更新供具备Playwright/Chrome的后续环境复验。
