# FinModel Lab v1.4

教学交互与空间优化

在原FinModel Lab静态项目中完成字体系统更新：Bricolage Grotesque、Glow Sans SC Normal、Monaspace Argon / Neon、KaTeX。保留三栏与实验八；图表按可用区域重绘，文字和点位等比。v1.4完整清单、数学对照与真实截图见CHANGES-v1.4.md。

## 启动

无需安装前端依赖。在本目录运行：

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

然后打开 http://127.0.0.1:8765 。字体、KaTeX及应用文件全部自托管，不依赖外部字体CDN或市场行情。建议使用该HTTP启动方式完成字体与剪贴板功能。

## 操作

点击R代码的任意一行，查看完整逻辑语句、数学公式、实时代入与计算结果。调整资产A权重，B自动补足；收益率和标准差横向比较，ρ提供滑块与精确输入。点击当前组合或最小方差的点/底部图例查看详情。

“开始探索”支持预测→实验→解释，实验期间仅开放ρ调节；纯资产等情形可正确回答“不变”。“复制代码”导出可在基础R/RStudio整体运行的当前脚本。浏览器不执行任意R输入。

投屏模式：代码19px、解释17px、核心公式22px、指标36px、图表标签16px；Escape退出。其他实验仍提示“暂未上线”。手机通过菜单访问目录和帮助。

## 字体与结果

- 字体逐区方案、真实字重与授权：`FONTS.md`。
- 完整修改、加载、性能与回归报告：`CHANGES-v1.3.md`。
- 原版/新版/各区域/投屏截图：`tests/v1.3/gallery.html`。
- 浏览器检查记录：`tests/v1.3/checks.json`；首屏前后性能JSON与字形验证记录也在同目录。
- 字体来源/文件哈希/许可证：`dist/assets/`。
- `?audit=1`启用本地诊断记录；`font-specimen.html`是开发验收页，不在用户导航中，不收集或上传任何数据。

## 自动测试

```sh
node tests/math.test.cjs
node tests/learning.test.cjs
node tests/r-code.test.cjs   # 需Rscript
node tests/typography.test.cjs
```

通过：54,159个可行点检查、教学/参数边界检查、13组真实R执行、120个KaTeX公式/计算检查。`dist/math.js`与字体改版前逐字节一致。

浏览器实际操作验收65项通过，包含三种指定桌面尺寸、手机、投屏、字体字形加载、代码字符和金融联动。`tests/browser.test.cjs`为后续具备Playwright/Chrome环境提供重放，本次通过已连接内置浏览器实际操作完成。

## 字体构建

正常使用不需要构建字体。重新制作字体时，使用`tools/build-font-assets.py`与FontTools/Brotli，输入来自`font-sources.json`所列官方版本的暂存源文件。该工具检查实际中文覆盖、生成core/common WOFF2分包并保留许可证。Monaspace保留官方文件字节，不对子集修改后冒用保留名称。

## 发布

原`.openai/hosting.json`站点身份与配置保留；本次没有重试此前待授权的源码上传，也没有另建站点或切换部署平台。当前交付是可运行本地版本。

`FinModel-Lab-v1.3.zip`包含运行文件、字体、许可证、测试、完整说明及截图；`FinModel-Lab.zip`同步为此版本。
