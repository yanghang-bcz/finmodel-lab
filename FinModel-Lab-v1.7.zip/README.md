# FinModel Lab v1.7

现有实验08的探索流程专项修复，保留静态架构、三栏、字体、金融核心和全部原功能。

## 启动

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

在项目目录运行后打开 http://127.0.0.1:8765/ 。无需安装前端依赖，字体与KaTeX全部自托管。

## 操作

普通模式自由调参。点击“开始探索”记录当前参数并锁定全部输入；先选预测，再“确认预测，开始实验”。实验仅开放rho，最大值为本轮起点。有效降低后才可查看解释；解释锁定参数并显示真实表与推导。

“重新实验”回到同一起点，保留预测但清除旧结果；“重新开始”使用当前参数重新进入预测，清除旧选择和比较。退出可明确选择恢复首次实验前参数或保留当前参数；Escape和顶部“退出并恢复”恢复实验前参数。rho=-1时只有明确点击使用默认参数才会重置。

风险前后比较只在Portfolio Risk内，Predict绝不显示。普通比较与探索比较隔离。

代码可自由点选。没有手动调整时，简单解释保留72%代码、复杂解释保留55%；手调后保持用户比例。拖动/方向键/Home/End操作分隔条；展开解析保留40%代码，收起恢复原比例。代码和解释分别滚动。

默认38行基础R可复制到RStudio运行，无机器精度、容差或断言；特定抵消边界会补充有中文解释的等价公式。自动/固定比较坐标、关键点、投屏、目录提示保留。

## 验收

- 逐文件修改、完成状态、数学与实测：CHANGES-v1.7.md。
- 四阶段与全部截图：tests/v1.7/gallery.html。
- 79项浏览器断言：tests/v1.7/checks.json。
- 字体与授权：FONTS.md、dist/assets/。

```sh
node tests/exploration.test.cjs
node tests/math.test.cjs
node tests/learning.test.cjs
node tests/numerics.test.cjs
node tests/scale.test.cjs
node tests/r-code.test.cjs
node tests/typography.test.cjs
```

实际通过状态测试、54,159个可行点、384组数值一致性、16组R执行、120个公式/计算和本轮浏览器检查。复制出的默认/负相关R脚本也已实际运行。tests/browser.test.cjs为可选独立Playwright重放，本轮未运行；浏览器验收使用已连接的内置浏览器。未执行远程发布或真实课堂试用。
